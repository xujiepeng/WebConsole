CKEditor 5 classic editor build v15.0.0
=======================================

In order to start using CKEditor 5 Builds, configure or customize them, please visit http://docs.ckeditor.com/ckeditor5/latest/builds/index.html

## License

Licensed under the terms of [GNU General Public License Version 2 or later](http://www.gnu.org/licenses/gpl.html).
For full details about the license, please check the LICENSE.md file.
